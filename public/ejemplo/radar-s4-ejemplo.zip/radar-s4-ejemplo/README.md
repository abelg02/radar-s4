# Sistema de ejemplo de Radar S/4

Código Z FICTICIO de una empresa inventada, generado para probar Radar S/4. No pertenece a ninguna empresa real.
Los objetos estándar de SAP que usa sí son reales. El CSV de uso también es inventado.
