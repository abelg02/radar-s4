*&---------------------------------------------------------------------*
*& ZRMM_TRASPASOS
*& Informe del área MM
*& Creado en 2012. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_traspasos.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT ebeln ebelp matnr menge FROM ekpo INTO TABLE lt_ekpo WHERE ebeln IN s_ebeln.

  CALL FUNCTION 'BAPI_PO_CREATE1'
    EXPORTING
      poheader = ls_cabecera
    TABLES
      return   = lt_return
      poitem   = lt_posiciones.
  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
