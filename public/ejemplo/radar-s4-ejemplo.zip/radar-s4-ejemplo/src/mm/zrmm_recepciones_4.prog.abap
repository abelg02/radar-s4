*&---------------------------------------------------------------------*
*& ZRMM_RECEPCIONES_4
*& Informe del área MM
*& Creado en 2018. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_recepciones_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM mkpf INTO TABLE lt_mkpf WHERE budat IN s_budat.
  SELECT * FROM mseg INTO TABLE lt_mseg FOR ALL ENTRIES IN lt_mkpf WHERE mblnr = lt_mkpf-mblnr.

  CALL FUNCTION 'BAPI_PO_CREATE1'
    EXPORTING
      poheader = ls_cabecera
    TABLES
      return   = lt_return
      poitem   = lt_posiciones.
  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.

  " Cambio de la copia 4
  SORT lt_salida.
  DELETE ADJACENT DUPLICATES FROM lt_salida.
