*&---------------------------------------------------------------------*
*& ZRMM_RECEPCIONES
*& Informe del área MM
*& Creado en 2016. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_recepciones.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM lfa1 INTO TABLE lt_lfa1 WHERE ktokk = 'ZNAC'.
  SELECT * FROM eban INTO TABLE lt_eban WHERE banfn IN s_banfn.

  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr = '01'
      object      = 'ZRADAR_DOC'
    IMPORTING
      number      = lv_numero.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'RECEPCIONES'
    IMPORTING
      ev_valor = lv_valor.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
