*&---------------------------------------------------------------------*
*& ZRMM_REAPROVISION
*& Informe del área MM
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_reaprovision.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  SELECT * FROM lfa1 INTO TABLE lt_lfa1 WHERE ktokk = 'ZNAC'.
  SELECT * FROM eban INTO TABLE lt_eban WHERE banfn IN s_banfn.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
