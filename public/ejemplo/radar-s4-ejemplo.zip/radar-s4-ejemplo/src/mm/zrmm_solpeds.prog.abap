*&---------------------------------------------------------------------*
*& ZRMM_SOLPEDS
*& Informe del área MM
*& Creado en 2021. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_solpeds.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  CALL FUNCTION 'READ_TEXT'
    EXPORTING
      id       = '0001'
      language = sy-langu
      name     = lv_nombre_texto
      object   = 'VBBK'
    TABLES
      lines    = lt_lineas.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'SOLPEDS'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
