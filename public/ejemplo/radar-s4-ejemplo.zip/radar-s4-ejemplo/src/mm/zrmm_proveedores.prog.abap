*&---------------------------------------------------------------------*
*& ZRMM_PROVEEDORES
*& Informe del área MM
*& Creado en 2011. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_proveedores.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
