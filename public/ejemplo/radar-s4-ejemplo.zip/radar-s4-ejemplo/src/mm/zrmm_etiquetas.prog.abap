*&---------------------------------------------------------------------*
*& ZRMM_ETIQUETAS
*& Informe del área MM
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_etiquetas.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  CALL TRANSACTION 'MB1A' USING lt_bdc MODE 'N' MESSAGES INTO lt_msg.

  SELECT * FROM lfa1 INTO TABLE lt_lfa1 WHERE ktokk = 'ZNAC'.
  SELECT * FROM eban INTO TABLE lt_eban WHERE banfn IN s_banfn.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'ETIQUETAS'
    IMPORTING
      ev_valor = lv_valor.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
