*&---------------------------------------------------------------------*
*& ZRMM_SOLPEDS_2
*& Informe del área MM
*& Creado en 2006. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_solpeds_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  CALL TRANSACTION 'MB1A' USING lt_bdc MODE 'N' MESSAGES INTO lt_msg.

  SELECT ebeln ebelp matnr menge FROM ekpo INTO TABLE lt_ekpo WHERE ebeln IN s_ebeln.

  CALL FUNCTION 'READ_TEXT'
    EXPORTING
      id       = '0001'
      language = sy-langu
      name     = lv_nombre_texto
      object   = 'VBBK'
    TABLES
      lines    = lt_lineas.

  CALL FUNCTION 'Z_RADAR_OBSOLETA_2009'
    EXPORTING
      iv_fichero = lv_fichero
    TABLES
      it_datos   = lt_salida.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
