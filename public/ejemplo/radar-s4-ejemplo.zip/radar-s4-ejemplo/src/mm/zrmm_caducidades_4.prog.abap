*&---------------------------------------------------------------------*
*& ZRMM_CADUCIDADES_4
*& Informe del área MM
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_caducidades_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  SELECT * FROM lfa1 INTO TABLE lt_lfa1 WHERE ktokk = 'ZNAC'.
  SELECT * FROM eban INTO TABLE lt_eban WHERE banfn IN s_banfn.

  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr = '01'
      object      = 'ZRADAR_DOC'
    IMPORTING
      number      = lv_numero.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'CADUCIDADES'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
