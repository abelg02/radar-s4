*&---------------------------------------------------------------------*
*& ZRMM_PEDIDOS_COMPRA
*& Informe del área MM
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_pedidos_compra.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT ebeln ebelp matnr menge FROM ekpo INTO TABLE lt_ekpo WHERE ebeln IN s_ebeln.

  SELECT ebeln ebelp matnr menge FROM ekpo INTO TABLE lt_ekpo WHERE ebeln IN s_ebeln.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'PEDIDOS_COMPRA'
    IMPORTING
      ev_valor = lv_valor.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
