*&---------------------------------------------------------------------*
*& ZRMM_STOCK_ALMACEN_2
*& Informe del área MM
*& Creado en 2011. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_stock_almacen_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT ebeln ebelp matnr menge FROM ekpo INTO TABLE lt_ekpo WHERE ebeln IN s_ebeln.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  " Cambio de la copia 2
  SORT lt_salida.
  DELETE ADJACENT DUPLICATES FROM lt_salida.
