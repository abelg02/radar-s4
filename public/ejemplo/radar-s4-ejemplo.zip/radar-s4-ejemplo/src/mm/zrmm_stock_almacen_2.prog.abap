*&---------------------------------------------------------------------*
*& ZRMM_STOCK_ALMACEN_2
*& Informe del área MM
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_stock_almacen_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  SELECT * FROM mkpf INTO TABLE lt_mkpf WHERE budat IN s_budat.
  SELECT * FROM mseg INTO TABLE lt_mseg FOR ALL ENTRIES IN lt_mkpf WHERE mblnr = lt_mkpf-mblnr.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'STOCK_ALMACEN'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
