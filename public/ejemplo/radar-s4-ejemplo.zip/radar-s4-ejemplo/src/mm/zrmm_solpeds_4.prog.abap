*&---------------------------------------------------------------------*
*& ZRMM_SOLPEDS_4
*& Informe del área MM
*& Creado en 2019. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_solpeds_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  CALL TRANSACTION 'MB1A' USING lt_bdc MODE 'N' MESSAGES INTO lt_msg.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.

  " Cambio de la copia 4
  SORT lt_salida.
  DELETE ADJACENT DUPLICATES FROM lt_salida.
