*&---------------------------------------------------------------------*
*& ZRMM_TRASPASOS_3
*& Informe del área MM
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrmm_traspasos_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM lfa1 INTO TABLE lt_lfa1 WHERE ktokk = 'ZNAC'.
  SELECT * FROM eban INTO TABLE lt_eban WHERE banfn IN s_banfn.

  CALL FUNCTION 'READ_TEXT'
    EXPORTING
      id       = '0001'
      language = sy-langu
      name     = lv_nombre_texto
      object   = 'VBBK'
    TABLES
      lines    = lt_lineas.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'TRASPASOS'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'Z_RADAR_OBSOLETA_2009'
    EXPORTING
      iv_fichero = lv_fichero
    TABLES
      it_datos   = lt_salida.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
