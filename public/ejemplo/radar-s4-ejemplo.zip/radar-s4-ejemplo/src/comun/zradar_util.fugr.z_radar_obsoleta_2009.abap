FUNCTION z_radar_obsoleta_2009.
*"  Ejemplo ficticio generado para Radar S/4
  CALL FUNCTION 'WS_DOWNLOAD'
    EXPORTING
      filename = iv_fichero
    TABLES
      data_tab = it_datos.
ENDFUNCTION.
