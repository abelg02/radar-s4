FUNCTION z_radar_fecha_laboral.
*"  Ejemplo ficticio generado para Radar S/4
  CALL FUNCTION 'DATE_CONVERT_TO_FACTORYDATE'
    EXPORTING
      date                = iv_fecha
      factory_calendar_id = 'ES'
    IMPORTING
      factorydate         = ev_dia.
ENDFUNCTION.
