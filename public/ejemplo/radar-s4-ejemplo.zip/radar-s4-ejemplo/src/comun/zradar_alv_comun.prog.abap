*&---------------------------------------------------------------------*
*& Include ZRADAR_ALV_COMUN (ejemplo ficticio)
*&---------------------------------------------------------------------*
FORM mostrar_alv TABLES pt_datos.
  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
ENDFORM.
