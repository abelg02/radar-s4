FUNCTION z_radar_log.
*"  Ejemplo ficticio generado para Radar S/4
  INSERT zradar_log FROM ls_log.
ENDFUNCTION.
