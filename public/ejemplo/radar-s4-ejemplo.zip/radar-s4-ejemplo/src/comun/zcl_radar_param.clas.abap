"! Ejemplo ficticio generado para Radar S/4 (2021)
CLASS zcl_radar_param DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS get.
ENDCLASS.

CLASS zcl_radar_param IMPLEMENTATION.
  METHOD get.
    SELECT SINGLE FROM zradar_param FIELDS valor WHERE clave = 'X' INTO @DATA(lv_valor).
  ENDMETHOD.
ENDCLASS.
