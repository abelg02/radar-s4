FUNCTION z_radar_enviar_mail.
*"  Ejemplo ficticio generado para Radar S/4
  CALL FUNCTION 'SO_NEW_DOCUMENT_ATT_SEND_API1'
    EXPORTING
      document_data = ls_doc
    TABLES
      receivers     = lt_dest.
ENDFUNCTION.
