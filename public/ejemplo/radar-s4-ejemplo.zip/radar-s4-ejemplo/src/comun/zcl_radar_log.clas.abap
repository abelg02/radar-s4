"! Ejemplo ficticio generado para Radar S/4 (2023)
CLASS zcl_radar_log DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS add.
ENDCLASS.

CLASS zcl_radar_log IMPLEMENTATION.
  METHOD add.
    DATA(lo_log) = cl_bali_log=>create( ).
    INSERT zradar_log FROM @ls_log.
  ENDMETHOD.
ENDCLASS.
