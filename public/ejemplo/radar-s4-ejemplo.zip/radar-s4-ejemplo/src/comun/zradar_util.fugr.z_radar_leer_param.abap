FUNCTION z_radar_leer_param.
*"  Ejemplo ficticio generado para Radar S/4
  SELECT SINGLE valor FROM zradar_param INTO ev_valor WHERE clave = iv_clave.
ENDFUNCTION.
