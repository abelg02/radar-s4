*&---------------------------------------------------------------------*
*& Include ZRADAR_TOP_COMUN (ejemplo ficticio)
*&---------------------------------------------------------------------*
TABLES: t001.
DATA: gt_param TYPE STANDARD TABLE OF zradar_param WITH HEADER LINE.
SELECT * FROM zradar_param INTO TABLE gt_param.
