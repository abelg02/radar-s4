" Ampliación implícita (ejemplo ficticio)
  IF sy-tcode = 'VA01'.
    SELECT SINGLE kbetr FROM konv INTO lv_kbetr WHERE knumv = vbak-knumv.
  ENDIF.