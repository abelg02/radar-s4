*&---------------------------------------------------------------------*
*& ZRPP_OEE
*& Informe del área PP
*& Creado en 2014. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_oee.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
