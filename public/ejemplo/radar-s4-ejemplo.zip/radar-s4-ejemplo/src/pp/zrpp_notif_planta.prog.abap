*&---------------------------------------------------------------------*
*& ZRPP_NOTIF_PLANTA
*& Informe del área PP
*& Creado en 2016. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_notif_planta.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM mkpf INTO TABLE lt_mkpf WHERE budat IN s_budat.
  SELECT * FROM mseg INTO TABLE lt_mseg FOR ALL ENTRIES IN lt_mkpf WHERE mblnr = lt_mkpf-mblnr.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'NOTIF_PLANTA'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'Z_RADAR_OBSOLETA_2009'
    EXPORTING
      iv_fichero = lv_fichero
    TABLES
      it_datos   = lt_salida.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.
