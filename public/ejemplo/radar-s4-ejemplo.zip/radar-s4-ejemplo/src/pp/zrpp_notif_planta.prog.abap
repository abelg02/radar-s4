*&---------------------------------------------------------------------*
*& ZRPP_NOTIF_PLANTA
*& Informe del área PP
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_notif_planta.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM mkpf INTO TABLE lt_mkpf WHERE budat IN s_budat.
  SELECT * FROM mseg INTO TABLE lt_mseg FOR ALL ENTRIES IN lt_mkpf WHERE mblnr = lt_mkpf-mblnr.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  CALL FUNCTION 'BAPI_GOODSMVT_CREATE'
    EXPORTING
      goodsmvt_header = ls_cabecera
      goodsmvt_code   = ls_codigo
    TABLES
      goodsmvt_item   = lt_items
      return          = lt_return.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'NOTIF_PLANTA'
    IMPORTING
      ev_valor = lv_valor.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
