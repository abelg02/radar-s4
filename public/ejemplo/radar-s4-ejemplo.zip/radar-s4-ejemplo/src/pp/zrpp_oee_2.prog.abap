*&---------------------------------------------------------------------*
*& ZRPP_OEE_2
*& Informe del área PP
*& Creado en 2012. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_oee_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  DATA lv_matnr(18) TYPE c.
  SELECT SINGLE * FROM mara INTO ls_mara WHERE matnr = lv_matnr.

  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr = '01'
      object      = 'ZRADAR_DOC'
    IMPORTING
      number      = lv_numero.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
