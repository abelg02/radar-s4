*&---------------------------------------------------------------------*
*& ZRPP_PARADAS
*& Informe del área PP
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_paradas.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  SELECT * FROM mkpf INTO TABLE lt_mkpf WHERE budat IN s_budat.
  SELECT * FROM mseg INTO TABLE lt_mseg FOR ALL ENTRIES IN lt_mkpf WHERE mblnr = lt_mkpf-mblnr.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
