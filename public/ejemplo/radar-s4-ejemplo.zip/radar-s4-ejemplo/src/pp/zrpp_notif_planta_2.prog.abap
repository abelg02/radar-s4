*&---------------------------------------------------------------------*
*& ZRPP_NOTIF_PLANTA_2
*& Informe del área PP
*& Creado en 2014. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrpp_notif_planta_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr = '01'
      object      = 'ZRADAR_DOC'
    IMPORTING
      number      = lv_numero.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'NOTIF_PLANTA'
    IMPORTING
      ev_valor = lv_valor.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
