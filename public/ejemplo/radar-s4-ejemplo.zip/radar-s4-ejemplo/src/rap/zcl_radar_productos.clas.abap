"! Ejemplo ficticio generado para Radar S/4 (2022)
CLASS zcl_radar_productos DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_productos IMPLEMENTATION.
  METHOD leer.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.

  METHOD procesar.
    SELECT FROM i_journalentryitem
      FIELDS companycode, accountingdocument, amountincompanycodecurrency
      WHERE companycode = '1000'
      INTO TABLE @DATA(lt_apuntes).
  ENDMETHOD.
ENDCLASS.
