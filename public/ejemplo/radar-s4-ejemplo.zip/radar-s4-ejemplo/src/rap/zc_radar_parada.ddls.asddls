@EndUserText.label: 'Paradas de planta (proyección)'
define root view entity ZC_RADAR_PARADA
  provider contract transactional_query
  as projection on ZI_RADAR_PARADA
{
  key Orden,
      Minutos
}
