@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Paradas de planta'
define root view entity ZI_RADAR_PARADA
  as select from zradar_paradas
  association [0..1] to I_Product as _Producto on $projection.Orden = _Producto.Product
{
  key aufnr   as Orden,
      minutos as Minutos,
      _Producto
}
