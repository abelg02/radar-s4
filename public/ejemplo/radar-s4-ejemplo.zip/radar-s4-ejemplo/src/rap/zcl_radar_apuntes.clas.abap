"! Ejemplo ficticio generado para Radar S/4 (2023)
CLASS zcl_radar_apuntes DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_apuntes IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_journalentryitem
      FIELDS companycode, accountingdocument, amountincompanycodecurrency
      WHERE companycode = '1000'
      INTO TABLE @DATA(lt_apuntes).
  ENDMETHOD.

  METHOD procesar.
    SELECT FROM i_journalentryitem
      FIELDS companycode, accountingdocument, amountincompanycodecurrency
      WHERE companycode = '1000'
      INTO TABLE @DATA(lt_apuntes).
  ENDMETHOD.
ENDCLASS.
