"! Ejemplo ficticio generado para Radar S/4 (2024)
CLASS zbp_radar_parada DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS validar.
ENDCLASS.

CLASS zbp_radar_parada IMPLEMENTATION.
  METHOD validar.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.
ENDCLASS.
