"! Ejemplo ficticio generado para Radar S/4 (2024)
CLASS zcl_radar_cierre DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_cierre IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_journalentryitem
      FIELDS companycode, accountingdocument, amountincompanycodecurrency
      WHERE companycode = '1000'
      INTO TABLE @DATA(lt_apuntes).
  ENDMETHOD.

  METHOD procesar.
    DATA(lo_log) = cl_bali_log=>create( ).
  ENDMETHOD.
ENDCLASS.
