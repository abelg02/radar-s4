"! Ejemplo ficticio generado para Radar S/4 (2023)
CLASS zcl_radar_cierre DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_cierre IMPLEMENTATION.
  METHOD leer.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.

  METHOD procesar.
    DATA(lo_log) = cl_bali_log=>create( ).
  ENDMETHOD.
ENDCLASS.
