@EndUserText.label: 'Ventas por cliente'
define view entity ZI_RADAR_VENTAS_CUBO
  as select from I_SalesDocument
  association [0..1] to I_Customer as _Cliente on $projection.Cliente = _Cliente.Customer
{
  key SalesDocument  as Pedido,
      SoldToParty    as Cliente,
      TotalNetAmount as Importe,
      _Cliente
}
