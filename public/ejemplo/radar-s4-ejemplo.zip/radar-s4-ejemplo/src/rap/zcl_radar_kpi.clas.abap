"! Ejemplo ficticio generado para Radar S/4 (2024)
CLASS zcl_radar_kpi DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_kpi IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_salesdocument
      FIELDS salesdocument, soldtoparty, totalnetamount
      WHERE salesdocumenttype = 'TA'
      INTO TABLE @DATA(lt_pedidos).
  ENDMETHOD.

  METHOD procesar.
    SELECT FROM i_salesdocument
      FIELDS salesdocument, soldtoparty, totalnetamount
      WHERE salesdocumenttype = 'TA'
      INTO TABLE @DATA(lt_pedidos).
  ENDMETHOD.
ENDCLASS.
