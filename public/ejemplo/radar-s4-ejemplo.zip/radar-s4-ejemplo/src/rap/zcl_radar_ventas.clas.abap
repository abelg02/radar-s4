"! Ejemplo ficticio generado para Radar S/4 (2025)
CLASS zcl_radar_ventas DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_ventas IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_salesdocument
      FIELDS salesdocument, soldtoparty, totalnetamount
      WHERE salesdocumenttype = 'TA'
      INTO TABLE @DATA(lt_pedidos).
  ENDMETHOD.

  METHOD procesar.
    DATA(lo_log) = cl_bali_log=>create( ).
  ENDMETHOD.
ENDCLASS.
