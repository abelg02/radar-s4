"! Ejemplo ficticio generado para Radar S/4 (2022)
CLASS zcl_radar_margen DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_margen IMPLEMENTATION.
  METHOD leer.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.

  METHOD procesar.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.
ENDCLASS.
