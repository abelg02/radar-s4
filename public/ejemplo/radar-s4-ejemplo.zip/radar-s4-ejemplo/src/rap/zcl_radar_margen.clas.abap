"! Ejemplo ficticio generado para Radar S/4 (2025)
CLASS zcl_radar_margen DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_margen IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_product
      FIELDS product, producttype
      WHERE producttype = 'FERT'
      INTO TABLE @DATA(lt_productos).
  ENDMETHOD.

  METHOD procesar.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.
ENDCLASS.
