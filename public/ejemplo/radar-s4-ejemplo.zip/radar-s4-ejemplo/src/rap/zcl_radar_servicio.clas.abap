"! Ejemplo ficticio generado para Radar S/4 (2022)
CLASS zcl_radar_servicio DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_servicio IMPLEMENTATION.
  METHOD leer.
    DATA(lv_hoy) = cl_abap_context_info=>get_system_date( ).
  ENDMETHOD.

  METHOD procesar.
    SELECT FROM i_product
      FIELDS product, producttype
      WHERE producttype = 'FERT'
      INTO TABLE @DATA(lt_productos).
  ENDMETHOD.
ENDCLASS.
