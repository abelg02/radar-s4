"! Ejemplo ficticio generado para Radar S/4 (2025)
CLASS zcl_radar_prevision DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS leer.
    METHODS procesar.
ENDCLASS.

CLASS zcl_radar_prevision IMPLEMENTATION.
  METHOD leer.
    SELECT FROM i_salesdocument
      FIELDS salesdocument, soldtoparty, totalnetamount
      WHERE salesdocumenttype = 'TA'
      INTO TABLE @DATA(lt_pedidos).
  ENDMETHOD.

  METHOD procesar.
    SELECT FROM i_journalentryitem
      FIELDS companycode, accountingdocument, amountincompanycodecurrency
      WHERE companycode = '1000'
      INTO TABLE @DATA(lt_apuntes).
  ENDMETHOD.
ENDCLASS.
