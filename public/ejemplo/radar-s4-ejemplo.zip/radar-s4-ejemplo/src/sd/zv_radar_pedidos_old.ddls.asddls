@AbapCatalog.sqlViewName: 'ZVRADARPED'
@EndUserText.label: 'Pedidos (vista antigua)'
define view ZV_RADAR_PEDIDOS_OLD as select from vbak
  inner join vbuk on vbak.vbeln = vbuk.vbeln
{
  vbak.vbeln,
  vbak.kunnr,
  vbuk.gbstk
}
