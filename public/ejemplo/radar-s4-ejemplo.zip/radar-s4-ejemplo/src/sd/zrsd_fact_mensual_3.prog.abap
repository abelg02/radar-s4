*&---------------------------------------------------------------------*
*& ZRSD_FACT_MENSUAL_3
*& Informe del área SD
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_fact_mensual_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.

  SELECT * FROM vbuk INTO TABLE lt_vbuk WHERE vbeln IN s_vbeln.
  LOOP AT lt_vbuk INTO ls_vbuk WHERE gbstk <> 'C'.
    APPEND ls_vbuk-vbeln TO lt_abiertos.
  ENDLOOP.

  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'FACT_MENSUAL'
    IMPORTING
      ev_valor = lv_valor.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
