*&---------------------------------------------------------------------*
*& ZRSD_CONSIGNA
*& Informe del área SD
*& Creado en 2011. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_consigna.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM vbuk INTO TABLE lt_vbuk WHERE vbeln IN s_vbeln.
  LOOP AT lt_vbuk INTO ls_vbuk WHERE gbstk <> 'C'.
    APPEND ls_vbuk-vbeln TO lt_abiertos.
  ENDLOOP.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'CONSIGNA'
    IMPORTING
      ev_valor = lv_valor.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
