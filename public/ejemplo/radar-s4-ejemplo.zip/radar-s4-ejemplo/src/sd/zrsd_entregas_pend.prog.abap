*&---------------------------------------------------------------------*
*& ZRSD_ENTREGAS_PEND
*& Informe del área SD
*& Creado en 2012. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_entregas_pend.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT vbeln erdat netwr FROM vbak INTO TABLE lt_vbak WHERE erdat IN s_erdat.
  LOOP AT lt_vbak INTO ls_vbak.
    SELECT SINGLE name1 FROM kna1 INTO lv_nombre WHERE kunnr = ls_vbak-kunnr.
  ENDLOOP.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  CALL FUNCTION 'BAPI_PO_CREATE1'
    EXPORTING
      poheader = ls_cabecera
    TABLES
      return   = lt_return
      poitem   = lt_posiciones.
  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
