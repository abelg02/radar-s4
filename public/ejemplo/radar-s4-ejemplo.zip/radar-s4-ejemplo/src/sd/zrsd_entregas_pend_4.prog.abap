*&---------------------------------------------------------------------*
*& ZRSD_ENTREGAS_PEND_4
*& Informe del área SD
*& Creado en 2019. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_entregas_pend_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM vbuk INTO TABLE lt_vbuk WHERE vbeln IN s_vbeln.
  LOOP AT lt_vbuk INTO ls_vbuk WHERE gbstk <> 'C'.
    APPEND ls_vbuk-vbeln TO lt_abiertos.
  ENDLOOP.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  CALL FUNCTION 'BAPI_GOODSMVT_CREATE'
    EXPORTING
      goodsmvt_header = ls_cabecera
      goodsmvt_code   = ls_codigo
    TABLES
      goodsmvt_item   = lt_items
      return          = lt_return.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
