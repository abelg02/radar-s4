*&---------------------------------------------------------------------*
*& ZRSD_BLOQUEOS_CREDITO
*& Informe del área SD
*& Creado en 2018. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_bloqueos_credito.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM vbup INTO TABLE lt_vbup WHERE vbeln = lv_vbeln.
  READ TABLE lt_vbup INTO ls_vbup INDEX 1.

  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
