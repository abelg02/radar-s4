*&---------------------------------------------------------------------*
*& ZRSD_ENTREGAS_PEND_2
*& Informe del área SD
*& Creado en 2014. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_entregas_pend_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  SELECT vbeln erdat netwr FROM vbak INTO TABLE lt_vbak WHERE erdat IN s_erdat.
  LOOP AT lt_vbak INTO ls_vbak.
    SELECT SINGLE name1 FROM kna1 INTO lv_nombre WHERE kunnr = ls_vbak-kunnr.
  ENDLOOP.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
