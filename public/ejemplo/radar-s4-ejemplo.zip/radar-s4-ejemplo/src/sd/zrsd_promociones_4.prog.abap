*&---------------------------------------------------------------------*
*& ZRSD_PROMOCIONES_4
*& Informe del área SD
*& Creado en 2011. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_promociones_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.

  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'PROMOCIONES'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.

  " Cambio de la copia 4
  SORT lt_salida.
  DELETE ADJACENT DUPLICATES FROM lt_salida.
