*&---------------------------------------------------------------------*
*& ZRSD_RUTAS_REPARTO_2
*& Informe del área SD
*& Creado en 2016. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_rutas_reparto_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM kna1 INTO ls_kna1 WHERE kunnr = lv_kunnr.
  SELECT * FROM knvv INTO TABLE lt_knvv WHERE kunnr = lv_kunnr.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'RUTAS_REPARTO'
    IMPORTING
      ev_valor = lv_valor.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
