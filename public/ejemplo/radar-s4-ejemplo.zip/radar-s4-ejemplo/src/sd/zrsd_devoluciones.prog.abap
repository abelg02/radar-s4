*&---------------------------------------------------------------------*
*& ZRSD_DEVOLUCIONES
*& Informe del área SD
*& Creado en 2021. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_devoluciones.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.

  SELECT * FROM vbup INTO TABLE lt_vbup WHERE vbeln = lv_vbeln.
  READ TABLE lt_vbup INTO ls_vbup INDEX 1.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'DEVOLUCIONES'
    IMPORTING
      ev_valor = lv_valor.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
