*&---------------------------------------------------------------------*
*& ZRSD_COMISIONES
*& Informe del área SD
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_comisiones.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.

  SELECT * FROM vbuk INTO TABLE lt_vbuk WHERE vbeln IN s_vbeln.
  LOOP AT lt_vbuk INTO ls_vbuk WHERE gbstk <> 'C'.
    APPEND ls_vbuk-vbeln TO lt_abiertos.
  ENDLOOP.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'COMISIONES'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'Z_RADAR_OBSOLETA_2009'
    EXPORTING
      iv_fichero = lv_fichero
    TABLES
      it_datos   = lt_salida.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
