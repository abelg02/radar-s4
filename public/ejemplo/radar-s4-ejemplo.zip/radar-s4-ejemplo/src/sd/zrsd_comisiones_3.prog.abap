*&---------------------------------------------------------------------*
*& ZRSD_COMISIONES_3
*& Informe del área SD
*& Creado en 2019. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrsd_comisiones_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM vbup INTO TABLE lt_vbup WHERE vbeln = lv_vbeln.
  READ TABLE lt_vbup INTO ls_vbup INDEX 1.

  SELECT * FROM vbuk INTO TABLE lt_vbuk WHERE vbeln IN s_vbeln.
  LOOP AT lt_vbuk INTO ls_vbuk WHERE gbstk <> 'C'.
    APPEND ls_vbuk-vbeln TO lt_abiertos.
  ENDLOOP.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
