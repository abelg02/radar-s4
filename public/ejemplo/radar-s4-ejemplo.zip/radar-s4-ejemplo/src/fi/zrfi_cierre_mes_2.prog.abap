*&---------------------------------------------------------------------*
*& ZRFI_CIERRE_MES_2
*& Informe del área FI
*& Creado en 2012. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_cierre_mes_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM bkpf INTO ls_bkpf WHERE bukrs = p_bukrs AND belnr = lv_belnr AND gjahr = p_gjahr.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  MODIFY mara FROM ls_mara.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.
