*&---------------------------------------------------------------------*
*& ZRFI_PARTIDAS_ABIERTAS_3
*& Informe del área FI
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_partidas_abiertas_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  CALL FUNCTION 'READ_TEXT'
    EXPORTING
      id       = '0001'
      language = sy-langu
      name     = lv_nombre_texto
      object   = 'VBBK'
    TABLES
      lines    = lt_lineas.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
