*&---------------------------------------------------------------------*
*& ZRFI_CENTROS_COSTE_3
*& Informe del área FI
*& Creado en 2021. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_centros_coste_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bseg INTO TABLE lt_bseg WHERE bukrs = p_bukrs AND gjahr = p_gjahr.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
