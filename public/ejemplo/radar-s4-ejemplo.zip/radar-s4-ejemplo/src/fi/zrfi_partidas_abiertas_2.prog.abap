*&---------------------------------------------------------------------*
*& ZRFI_PARTIDAS_ABIERTAS_2
*& Informe del área FI
*& Creado en 2019. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_partidas_abiertas_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
