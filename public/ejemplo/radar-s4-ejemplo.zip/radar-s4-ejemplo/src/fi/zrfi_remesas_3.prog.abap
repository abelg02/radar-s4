*&---------------------------------------------------------------------*
*& ZRFI_REMESAS_3
*& Informe del área FI
*& Creado en 2018. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_remesas_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
