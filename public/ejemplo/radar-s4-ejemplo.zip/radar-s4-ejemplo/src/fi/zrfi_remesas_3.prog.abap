*&---------------------------------------------------------------------*
*& ZRFI_REMESAS_3
*& Informe del área FI
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_remesas_3.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  MOVE lv_valor TO ls_salida.
  ADD 1 TO lv_contador.
  REFRESH lt_salida.
