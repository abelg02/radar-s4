*&---------------------------------------------------------------------*
*& ZRFI_REMESAS_2
*& Informe del área FI
*& Creado en 2016. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_remesas_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.

  " Cambio de la copia 2
  SORT lt_salida.
  DELETE ADJACENT DUPLICATES FROM lt_salida.
