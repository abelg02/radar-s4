*&---------------------------------------------------------------------*
*& ZRFI_REMESAS_2
*& Informe del área FI
*& Creado en 2019. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_remesas_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.
