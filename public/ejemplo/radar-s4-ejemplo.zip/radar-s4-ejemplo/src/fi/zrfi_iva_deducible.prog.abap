*&---------------------------------------------------------------------*
*& ZRFI_IVA_DEDUCIBLE
*& Informe del área FI
*& Creado en 2021. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_iva_deducible.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  SELECT SINGLE * FROM bkpf INTO ls_bkpf WHERE bukrs = p_bukrs AND belnr = lv_belnr AND gjahr = p_gjahr.

  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
