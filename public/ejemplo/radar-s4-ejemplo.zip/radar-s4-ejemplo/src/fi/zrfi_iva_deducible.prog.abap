*&---------------------------------------------------------------------*
*& ZRFI_IVA_DEDUCIBLE
*& Informe del área FI
*& Creado en 2014. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_iva_deducible.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsid INTO TABLE lt_bsid WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.
  SELECT * FROM bsad INTO TABLE lt_bsad WHERE bukrs = p_bukrs AND kunnr IN s_kunnr.

  SELECT * FROM bseg INTO TABLE lt_bseg WHERE bukrs = p_bukrs AND gjahr = p_gjahr.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.
