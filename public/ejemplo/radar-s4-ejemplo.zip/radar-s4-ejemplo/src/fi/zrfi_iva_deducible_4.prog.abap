*&---------------------------------------------------------------------*
*& ZRFI_IVA_DEDUCIBLE_4
*& Informe del área FI
*& Creado en 2009. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_iva_deducible_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM bkpf INTO ls_bkpf WHERE bukrs = p_bukrs AND belnr = lv_belnr AND gjahr = p_gjahr.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.

  CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
    EXPORTING
      i_callback_program = sy-repid
      it_fieldcat        = lt_fieldcat
    TABLES
      t_outtab           = lt_salida.
