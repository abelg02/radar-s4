*&---------------------------------------------------------------------*
*& ZRFI_ASIENTOS_MASIVOS_2
*& Informe del área FI
*& Creado en 2008. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_asientos_masivos_2.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bsik INTO TABLE lt_bsik WHERE bukrs = p_bukrs.

  CALL FUNCTION 'BAPI_PO_CREATE1'
    EXPORTING
      poheader = ls_cabecera
    TABLES
      return   = lt_return
      poitem   = lt_posiciones.
  CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'ASIENTOS_MASIVOS'
    IMPORTING
      ev_valor = lv_valor.

  LOOP AT lt_salida INTO ls_salida.
    WRITE: / ls_salida.
  ENDLOOP.
