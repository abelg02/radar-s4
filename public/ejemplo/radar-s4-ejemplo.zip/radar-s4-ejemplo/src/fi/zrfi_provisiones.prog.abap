*&---------------------------------------------------------------------*
*& ZRFI_PROVISIONES
*& Informe del área FI
*& Creado en 2011. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_provisiones.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT SINGLE * FROM bkpf INTO ls_bkpf WHERE bukrs = p_bukrs AND belnr = lv_belnr AND gjahr = p_gjahr.

  CALL FUNCTION 'BAPI_GOODSMVT_CREATE'
    EXPORTING
      goodsmvt_header = ls_cabecera
      goodsmvt_code   = ls_codigo
    TABLES
      goodsmvt_item   = lt_items
      return          = lt_return.

  PERFORM mostrar_alv TABLES lt_salida.

INCLUDE zradar_alv_comun.
