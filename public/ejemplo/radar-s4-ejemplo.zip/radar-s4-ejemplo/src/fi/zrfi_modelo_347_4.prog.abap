*&---------------------------------------------------------------------*
*& ZRFI_MODELO_347_4
*& Informe del área FI
*& Creado en 2014. Ejemplo ficticio generado para Radar S/4.
*&---------------------------------------------------------------------*
REPORT zrfi_modelo_347_4.

INCLUDE zradar_top_comun.

DATA: lt_salida TYPE STANDARD TABLE OF string, ls_salida TYPE string.

START-OF-SELECTION.

  SELECT * FROM bseg INTO TABLE lt_bseg WHERE bukrs = p_bukrs AND gjahr = p_gjahr.

  SELECT * FROM bseg INTO TABLE lt_bseg WHERE bukrs = p_bukrs AND gjahr = p_gjahr.

  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.

  CALL FUNCTION 'Z_RADAR_LEER_PARAM'
    EXPORTING
      iv_clave = 'MODELO_347'
    IMPORTING
      ev_valor = lv_valor.

  CALL FUNCTION 'GUI_DOWNLOAD'
    EXPORTING
      filename = lv_fichero
    TABLES
      data_tab = lt_salida.
