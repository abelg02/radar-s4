FUNCTION z_radar_rfc_antigua.
*"  Ejemplo ficticio generado para Radar S/4
  SELECT * FROM bsik INTO TABLE et_partidas WHERE lifnr = iv_lifnr.
ENDFUNCTION.
