FUNCTION z_radar_rfc_stock.
*"  Ejemplo ficticio generado para Radar S/4
  SELECT matnr werks lgort labst FROM mard INTO TABLE et_stock WHERE werks = iv_centro.
ENDFUNCTION.
