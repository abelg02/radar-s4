FUNCTION z_radar_rfc_cliente_alta.
*"  Ejemplo ficticio generado para Radar S/4
  INSERT kna1 FROM ls_kna1.
  INSERT knvv FROM ls_knvv.
ENDFUNCTION.
