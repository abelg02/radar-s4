"! Ejemplo ficticio generado para Radar S/4 (2017)
CLASS zcl_radar_int_web DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    METHODS enviar.
    METHODS registrar.
ENDCLASS.

CLASS zcl_radar_int_web IMPLEMENTATION.
  METHOD enviar.
    DATA lo_http TYPE REF TO if_http_client.
    cl_http_client=>create_by_url( EXPORTING url = lv_url IMPORTING client = lo_http ).
    lo_http->send( ).
  ENDMETHOD.

  METHOD registrar.
    CALL FUNCTION 'Z_RADAR_LOG'
      EXPORTING
        is_log = ls_log.
  ENDMETHOD.
ENDCLASS.
