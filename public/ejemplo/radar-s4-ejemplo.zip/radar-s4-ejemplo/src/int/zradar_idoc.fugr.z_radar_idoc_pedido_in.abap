FUNCTION z_radar_idoc_pedido_in.
*"  Ejemplo ficticio generado para Radar S/4
  CALL FUNCTION 'BAPI_SALESORDER_CREATEFROMDAT2'
    EXPORTING
      order_header_in = ls_cabecera
    TABLES
      return          = lt_return.
  INSERT zradar_cola FROM ls_cola.
ENDFUNCTION.
