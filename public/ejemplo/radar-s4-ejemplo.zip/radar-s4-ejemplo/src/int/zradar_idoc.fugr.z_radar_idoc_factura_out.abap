FUNCTION z_radar_idoc_factura_out.
*"  Ejemplo ficticio generado para Radar S/4
  SELECT * FROM vbrk INTO TABLE lt_vbrk WHERE fkdat = sy-datum.
  SELECT * FROM vbrp INTO TABLE lt_vbrp FOR ALL ENTRIES IN lt_vbrk WHERE vbeln = lt_vbrk-vbeln.
  CALL FUNCTION 'MASTER_IDOC_DISTRIBUTE'
    EXPORTING
      master_idoc_control = ls_control
    TABLES
      communication_idoc_control = lt_control
      master_idoc_data    = lt_data.
ENDFUNCTION.
