FUNCTION z_radar_rfc_precio.
*"  Ejemplo ficticio generado para Radar S/4
  SELECT knumv kposn kschl kbetr FROM konv INTO TABLE lt_konv
    FOR ALL ENTRIES IN lt_pedidos WHERE knumv = lt_pedidos-knumv.
ENDFUNCTION.
